### Setup
`npm install`

#### Dev

`npm run start`

Navigate to `localhost:8080`
